package com.example.stickherogame;

public class StickHeroCharacter {
    private double stick_length;

    public StickHeroCharacter() {
    }

    public void extendStickLength() {
    }
}