package com.example.stickherogame;

public class GamePlay {
    private double stickLength;
    private int cherriesCollected;
    private int score;
    public void move() {
    }
    public void startLevel() {
    }
    public void endLevel(){}
    public void collectCherries() {
    }
    public void revivePlayer() {
    }
    public void saveProgress() {
    }
}