package com.example.stickherogame;

public class GameView {
    private GameController gameController;

    public GameView(GameController gamecontroller) {
        this.gameController = gamecontroller;
    }

    public void displayGame() {
    }

    public void updateView() {
    }
}