package com.example.stickherogame;

import java.util.ArrayList;

public class GameController extends GamePlay{
    private StickHeroCharacter stickhero;
    private ArrayList<Platform> platforms = new ArrayList<>();
    public GameController(){
    }
    public void startGame(){
    }
    public void endGame(){
    }
    public void resumeGame(){
    }
    public void restartGame(){}
    public void pauseGame(){
    }
    public void moveHero(){}
    public void movePlatform(){}

}
