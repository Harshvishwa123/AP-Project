package com.example.stickherogame;//package com.example.stickherogame;


import javafx.scene.shape.Line;

public class Stick extends Line {

}










