package com.example.stickherogame;

public class RevivingFeature {
    private int cherriesRequired;

    public boolean canRevive(GamePlay stickHero) {
        return false;
    }

    public void deductCherries(GamePlay stickHero) {
    }
}
