package com.example.stickherogame;

public class Rewards {
    private double position;

    public void generateCherry() {
    }

    class ScoringSystem {
        private int multiplier;

        public int calculateScore(GamePlay stickHero) {
            return 0;
        }
    }
}